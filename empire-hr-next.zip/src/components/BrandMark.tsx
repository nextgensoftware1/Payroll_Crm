export function BrandMark({ className = "size-9" }: { className?: string }) {
  return (
    <svg aria-hidden viewBox="0 0 32 32" className={className}>
      <path d="M16 2 28 9v14l-12 7L4 23V9z" fill="#087F8C" />
      <path d="M16 8 22.5 11.8v8.4L16 24l-6.5-3.8v-8.4z" fill="#0B1F33" />
      <path d="M16 12.2 19 14v4l-3 1.8-3-1.8v-4z" fill="#12B8B0" />
    </svg>
  );
}
